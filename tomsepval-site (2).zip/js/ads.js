// =========================================================
// LANDING LOCATION — compte à rebours + formulaire
// =========================================================
(function () {
  'use strict';

  // ---- Compte à rebours : fin de mois en cours ----
  var cd = document.getElementById('promo-countdown');
  if (cd) {
    var now = new Date();
    // Dernier jour du mois courant à 23:59:59
    var end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
    var els = {
      d: document.getElementById('cd-days'),
      h: document.getElementById('cd-hours'),
      m: document.getElementById('cd-min'),
      s: document.getElementById('cd-sec')
    };
    function pad(n) { return (n < 10 ? '0' : '') + n; }
    function tick() {
      var diff = Math.max(0, end - new Date());
      var d = Math.floor(diff / 86400000);
      var h = Math.floor(diff % 86400000 / 3600000);
      var m = Math.floor(diff % 3600000 / 60000);
      var s = Math.floor(diff % 60000 / 1000);
      els.d.textContent = pad(d);
      els.h.textContent = pad(h);
      els.m.textContent = pad(m);
      els.s.textContent = pad(s);
    }
    // setInterval dérive par rapport aux secondes réelles : au bout de
    // quelques minutes le chiffre des secondes saute une valeur ou en
    // répète une. On se recale sur la prochaine seconde pleine.
    (function schedule() {
      tick();
      setTimeout(schedule, 1000 - (Date.now() % 1000));
    })();
  }

  // ---- Bandeau défilant : figé quand il sort de l'écran ----
  var marquee = document.querySelector('.marquee-track');
  if (marquee && 'IntersectionObserver' in window) {
    new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        marquee.classList.toggle('is-paused', !entry.isIntersecting);
      });
    }, { threshold: 0 }).observe(marquee);
  }

  // ---- Formulaire ----
  // Mêmes réglages EmailJS que le reste du site.
  var EMAILJS_SERVICE_ID = 'service_w5n7idr';
  var EMAILJS_TEMPLATE_ID = 'template_aknwx43';

  var form = document.getElementById('ads-form');
  if (!form) return;

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var status = document.getElementById('ads-form-status');
    var submitBtn = form.querySelector('button[type="submit"]');

    var data = {
      entreprise: form.entreprise.value.trim(),
      telephone: form.telephone.value.trim(),
      email: form.email.value.trim(),
      activite: form.activite.value.trim(),
      budget: form.budget.value,
      deja: form.deja.value,
      message: form.message.value.trim() || '(non renseigné)',
      source: 'Landing gestion de pub — promo 300€'
    };

    var emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email);
    if (!data.entreprise || !data.telephone || !data.email || !data.activite || !data.budget || !data.deja) {
      status.textContent = 'Merci de remplir tous les champs obligatoires.';
      status.className = 'form-status err';
      return;
    }
    if (!emailOk) {
      status.textContent = 'Cet email ne semble pas valide.';
      status.className = 'form-status err';
      return;
    }

    var ready = typeof emailjs !== 'undefined' && EMAILJS_SERVICE_ID !== 'REMPLACE_MOI';

    // Fallback sans EmailJS : email pré-rempli, aucun lead perdu
    if (!ready) {
      var body = 'Demande via la landing Gestion de publicité (promo 300€)%0D%0A%0D%0A' +
        'Entreprise : ' + encodeURIComponent(data.entreprise) + '%0D%0A' +
        'Téléphone : ' + encodeURIComponent(data.telephone) + '%0D%0A' +
        'Email : ' + encodeURIComponent(data.email) + '%0D%0A' +
        'Activité : ' + encodeURIComponent(data.activite) + '%0D%0A' +
        'Budget pub envisagé : ' + encodeURIComponent(data.budget) + '%0D%0A' +
        'Déjà fait de la pub : ' + encodeURIComponent(data.deja) + '%0D%0A' +
        'Objectif : ' + encodeURIComponent(data.message);
      window.location.href = 'mailto:contact@tomsepval.fr?subject=' +
        encodeURIComponent('Demande gestion de pub — ' + data.entreprise) +
        '&body=' + body;
      status.textContent = 'Votre messagerie s\u2019ouvre avec la demande pré-remplie — il ne reste qu\u2019à envoyer.';
      status.className = 'form-status ok';
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Envoi en cours...';
    emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, data)
      .then(function () {
        status.textContent = 'C\u2019est envoyé — je vous recontacte sous 24h pour lancer vos campagnes.';
        status.className = 'form-status ok';
        form.reset();
      })
      .catch(function () {
        status.textContent = 'Erreur d\u2019envoi. Réessayez ou écrivez-moi : contact@tomsepval.fr';
        status.className = 'form-status err';
      })
      .finally(function () {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Je veux mes premiers clients';
      });
  });
})();
