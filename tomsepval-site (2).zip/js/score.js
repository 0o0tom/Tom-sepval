// =========================================================
// SCORE DE VISIBILITÉ LOCALE
// 6 axes × 3 questions. Oui = 2 pts, En partie = 1, Non = 0.
// Total /36 converti en /100.
//
// Capture du lead AU DÉMARRAGE (nom, email, tél) puis :
//  - envoi silencieux "Test démarré" (si EmailJS configuré)
//  - envoi "Test terminé" avec le score détaillé
//  - envoi "Demande d'audit" au clic de réservation
// Sans EmailJS : seule la réservation fonctionne (mailto).
// => Configurer EmailJS est indispensable pour récupérer
//    les leads qui abandonnent en cours de test.
// =========================================================
(function () {
  'use strict';

  var EMAILJS_SERVICE_ID = 'service_w5n7idr';
  var EMAILJS_TEMPLATE_ID = 'template_aknwx43';
  var TEL_OBLIGATOIRE = true;

  // ----- Vocabulaire adapté à l'activité -----
  var ACTIONS = {
    'Artisan':       'demander un devis',
    'Restaurateur':  'réserver une table',
    'Immobilier':    'demander une estimation',
    'Autre':         'vous contacter'
  };
  var DEMANDES = {
    'Artisan':       'demandes de devis',
    'Restaurateur':  'réservations',
    'Immobilier':    'contacts vendeurs',
    'Autre':         'demandes de clients'
  };

  // ----- Les 6 axes (mêmes que l'audit) -----
  var AXES = [
    {
      name: 'Visibilité locale',
      questions: [
        'Votre fiche Google (Google Business Profile) est-elle revendiquée et complète — horaires, téléphone, description, zone d\u2019intervention\u00a0?',
        'Y avez-vous ajouté des photos récentes, de moins de 3 mois\u00a0?',
        'Apparaissez-vous dans les 3 premiers résultats quand vous tapez «\u00a0votre métier + {ville}\u00a0» sur Google\u00a0?'
      ]
    },
    {
      name: 'Site web',
      questions: [
        'Avez-vous un site qui s\u2019affiche correctement sur mobile\u00a0?',
        'Se charge-t-il en moins de 3 secondes\u00a0?',
        'Un visiteur peut-il {action} en moins de 2 clics depuis votre page d\u2019accueil\u00a0?'
      ]
    },
    {
      name: 'Réseaux sociaux',
      questions: [
        'Publiez-vous au moins une fois par semaine\u00a0?',
        'Votre contenu montre-t-il concrètement votre travail — photos réelles, coulisses, réalisations\u00a0?',
        'Répondez-vous aux messages et commentaires en moins de 24\u00a0heures\u00a0?'
      ]
    },
    {
      name: 'E-réputation',
      questions: [
        'Avez-vous plus d\u2019avis Google que vos concurrents directs\u00a0?',
        'Votre note moyenne est-elle supérieure à 4,5\u00a0?',
        'Répondez-vous à tous les avis, y compris les négatifs\u00a0?'
      ]
    },
    {
      name: 'Publicité',
      questions: [
        'Avez-vous déjà lancé des campagnes publicitaires locales (Google ou Meta)\u00a0?',
        'Savez-vous précisément combien vous coûte un contact ou une demande\u00a0?',
        'Vos campagnes ciblent-elles uniquement votre vraie zone d\u2019intervention\u00a0?'
      ]
    },
    {
      name: 'Performance commerciale',
      questions: [
        'Savez-vous précisément d\u2019où viennent vos nouveaux clients\u00a0?',
        'Recevez-vous des {demandes} via internet chaque semaine\u00a0?',
        'Recontactez-vous systématiquement les prospects qui ne donnent pas suite\u00a0?'
      ]
    }
  ];

  var VERDICTS = [
    { min: 0,  title: 'Quasi invisible.',
      sub: 'Vos clients potentiels vous cherchent en ligne — et trouvent vos concurrents. La bonne nouvelle\u00a0: partir de loin, c\u2019est aussi là que chaque action rapporte le plus vite.' },
    { min: 40, title: 'Présent, mais sous-exploité.',
      sub: 'Les bases existent, mais des clients passent à côté de vous chaque semaine. Quelques réglages ciblés peuvent changer la donne rapidement.' },
    { min: 70, title: 'Une présence solide.',
      sub: 'Vous faites déjà mieux que la plupart des entreprises locales. L\u2019enjeu maintenant\u00a0: transformer cette visibilité en davantage de clients.' },
    { min: 90, title: 'Excellent.',
      sub: 'Peu de choses à corriger. L\u2019enjeu est de garder l\u2019avance — et d\u2019aller chercher les optimisations que vos concurrents ne verront pas.' }
  ];

  var WEAK_TIPS = {
    'Visibilité locale':       'C\u2019est souvent le levier le plus rapide\u00a0: une fiche Google optimisée peut changer vos résultats en quelques semaines.',
    'Site web':                'Un site qui ne convertit pas coûte plus cher qu\u2019un site qui n\u2019existe pas — chaque visiteur perdu est un client chez un concurrent.',
    'Réseaux sociaux':         'Des réseaux à l\u2019abandon envoient un signal\u00a0: «\u00a0cette entreprise dort\u00a0». Quelques publications régulières suffisent à inverser l\u2019image.',
    'E-réputation':            'Vos avis sont lus avant votre site. C\u2019est eux qui décident si on vous appelle — ou pas.',
    'Publicité':               'De la publicité sans mesure, c\u2019est de l\u2019argent jeté. Bien ciblée et suivie, c\u2019est le levier le plus prévisible qui existe.',
    'Performance commerciale': 'Attirer des visiteurs ne suffit pas\u00a0: si personne ne mesure ni ne relance, la visibilité ne devient jamais du chiffre d\u2019affaires.'
  };

  // ----- État -----
  var state = {
    activite: '', ville: '', nom: '', email: '', tel: '',
    currentAxis: 0,
    answers: AXES.map(function (a) { return a.questions.map(function () { return null; }); })
  };

  // ----- DOM -----
  var stepIntro  = document.getElementById('step-intro');
  var stepQuiz   = document.getElementById('step-quiz');
  var stepResult = document.getElementById('step-result');
  if (!stepIntro || !stepQuiz || !stepResult) return;

  var quizQuestions = document.getElementById('quiz-questions');
  var quizAxisLabel = document.getElementById('quiz-axis-label');
  var quizBar   = document.getElementById('quiz-bar');
  var btnStart  = document.getElementById('btn-start');
  var btnPrev   = document.getElementById('btn-prev');
  var btnNext   = document.getElementById('btn-next');
  var btnBook   = document.getElementById('btn-book');
  var btnRestart = document.getElementById('btn-restart');

  var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var QUIZ_ANIM = 200; // ms — doit rester aligné avec .quiz-questions-anim (score.css)
  quizQuestions.classList.add('quiz-questions-anim');

  function show(step) {
    [stepIntro, stepQuiz, stepResult].forEach(function (s) {
      s.hidden = (s !== step);
      s.classList.toggle('is-active', s === step);
    });
    window.scrollTo({ top: 0, behavior: 'auto' });
  }

  // Remonter uniquement si l'écran du quiz est réellement sorti par le haut.
  // Un scrollTo inconditionnel provoquait un saut alors qu'il n'y avait
  // rien à rattraper.
  function scrollToQuizIfNeeded() {
    var top = stepQuiz.getBoundingClientRect().top;
    if (top < -8) {
      window.scrollTo({
        top: window.pageYOffset + top - 16,
        behavior: reducedMotion ? 'auto' : 'smooth'
      });
    }
  }

  // Changement d'axe : sortie dans le sens de la navigation, entrée depuis
  // le côté opposé. direction = 1 on avance, -1 on revient.
  function swapAxis(direction) {
    if (reducedMotion) { renderAxis(); return; }
    var outClass = direction > 0 ? 'q-out-fwd' : 'q-out-back';
    var inClass  = direction > 0 ? 'q-in-fwd'  : 'q-in-back';
    quizQuestions.classList.add(outClass);
    setTimeout(function () {
      renderAxis();
      quizQuestions.classList.remove(outClass);
      quizQuestions.classList.add(inClass);
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          quizQuestions.classList.remove(inClass);
        });
      });
    }, QUIZ_ANIM);
  }

  function fillTokens(text) {
    return text
      .replace('{ville}', state.ville || 'votre ville')
      .replace('{action}', ACTIONS[state.activite] || ACTIONS['Autre'])
      .replace('{demandes}', DEMANDES[state.activite] || DEMANDES['Autre']);
  }

  // ----- Envoi EmailJS (silencieux, ne bloque jamais le visiteur) -----
  function emailjsReady() {
    return typeof emailjs !== 'undefined' && EMAILJS_SERVICE_ID !== 'REMPLACE_MOI';
  }
  function sendLead(type, extra) {
    if (!emailjsReady()) return Promise.resolve(false);
    var data = {
      type: type,
      nom: state.nom,
      email: state.email,
      tel: state.tel || '(non renseigné)',
      activite: state.activite,
      ville: state.ville,
      source: 'Score de visibilité locale'
    };
    if (extra) { Object.keys(extra).forEach(function (k) { data[k] = extra[k]; }); }
    return emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, data)
      .then(function () { return true; })
      .catch(function () { return false; });
  }

  // ----- Rendu d'un axe -----
  function renderAxis() {
    var axis = AXES[state.currentAxis];
    quizAxisLabel.textContent = (state.currentAxis + 1) + ' / 6 — ' + axis.name;
    quizBar.style.width = ((state.currentAxis) / 6 * 100) + '%';

    var html = '';
    axis.questions.forEach(function (q, qi) {
      var name = 'q-' + state.currentAxis + '-' + qi;
      var saved = state.answers[state.currentAxis][qi];
      html += '<div class="quiz-q"><p>' + fillTokens(q) + '</p><div class="quiz-options">';
      [['2', 'Oui'], ['1', 'En partie'], ['0', 'Non']].forEach(function (opt) {
        var checked = saved === opt[0] ? ' checked' : '';
        html += '<label><input type="radio" name="' + name + '" value="' + opt[0] + '"' + checked + '><span>' + opt[1] + '</span></label>';
      });
      html += '</div></div>';
    });
    html += '<p class="quiz-hint" id="quiz-hint"></p>';
    quizQuestions.innerHTML = html;

    btnPrev.disabled = state.currentAxis === 0;
    btnNext.textContent = state.currentAxis === 5 ? 'Voir mon score' : 'Continuer';
  }

  function saveCurrentAxis() {
    var complete = true;
    AXES[state.currentAxis].questions.forEach(function (_, qi) {
      var sel = document.querySelector('input[name="q-' + state.currentAxis + '-' + qi + '"]:checked');
      state.answers[state.currentAxis][qi] = sel ? sel.value : null;
      if (!sel) complete = false;
    });
    return complete;
  }

  // ----- Calculs -----
  function axisScore(ai) {
    return state.answers[ai].reduce(function (sum, v) { return sum + (parseInt(v, 10) || 0); }, 0);
  }
  function totalScore() {
    var raw = AXES.reduce(function (sum, _, ai) { return sum + axisScore(ai); }, 0);
    return Math.round(raw / 36 * 100);
  }
  function verdictFor(score) {
    var v = VERDICTS[0];
    VERDICTS.forEach(function (t) { if (score >= t.min) v = t; });
    return v;
  }
  function weakestAxis() {
    var minIdx = 0;
    AXES.forEach(function (_, ai) { if (axisScore(ai) < axisScore(minIdx)) minIdx = ai; });
    return minIdx;
  }
  function scoreDetail() {
    return AXES.map(function (a, ai) { return a.name + ' : ' + axisScore(ai) + '/6'; }).join(' | ');
  }

  // ----- Résultat -----
  function renderResult() {
    var score = totalScore();
    var verdict = verdictFor(score);

    document.getElementById('score-verdict').textContent = verdict.title;
    document.getElementById('score-verdict-sub').textContent = verdict.sub;

    var axesEl = document.getElementById('axes-result');
    axesEl.innerHTML = AXES.map(function (a, ai) {
      var pts = axisScore(ai);
      return '<div class="axis-row">' +
        '<span class="axis-name">' + a.name + '</span>' +
        '<span class="axis-track"><span class="axis-fill" data-pct="' + (pts / 6 * 100) + '"></span></span>' +
        '<span class="axis-pts">' + pts + '/6</span>' +
      '</div>';
    }).join('');

    var weakEl = document.getElementById('score-weakpoint');
    if (score >= 95) {
      weakEl.innerHTML = '';
    } else {
      var wi = weakestAxis();
      weakEl.innerHTML = '<strong>Votre point faible n\u00b0 1\u00a0: ' + AXES[wi].name.toLowerCase() + '.</strong> ' + WEAK_TIPS[AXES[wi].name];
    }

    show(stepResult);

    // Envoi silencieux du résultat complet
    sendLead('Test terminé', { score: score + '/100', detail: scoreDetail() });

    // Animations (respecte prefers-reduced-motion)
    var numEl = document.getElementById('score-number');
    if (reducedMotion) {
      numEl.textContent = score;
    } else {
      // 600 ms : assez pour lire le décompte, sans faire attendre le
      // chiffre que le visiteur est précisément venu chercher.
      var start = null, dur = 600;
      requestAnimationFrame(function step(ts) {
        if (!start) start = ts;
        var p = Math.min((ts - start) / dur, 1);
        numEl.textContent = Math.round(score * (1 - Math.pow(1 - p, 3)));
        if (p < 1) requestAnimationFrame(step);
      });
    }
    requestAnimationFrame(function () {
      document.querySelectorAll('.axis-fill').forEach(function (f) {
        f.style.transform = 'scaleX(' + (parseFloat(f.getAttribute('data-pct')) / 100) + ')';
      });
    });
  }

  // ----- Démarrage : capture du lead -----
  btnStart.addEventListener('click', function () {
    var act   = document.getElementById('sc-activite').value;
    var ville = document.getElementById('sc-ville').value.trim();
    var nom   = document.getElementById('sc-nom').value.trim();
    var email = document.getElementById('sc-email').value.trim();
    var tel   = document.getElementById('sc-tel').value.trim();
    var note  = stepIntro.querySelector('.cta-note');

    var emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);

    if (!act || !ville || !nom || !email) {
      note.textContent = 'Remplissez tous les champs pour démarrer.';
      return;
    }
    if (!emailOk) {
      note.textContent = 'Cet email ne semble pas valide — vérifiez-le pour recevoir votre récapitulatif.';
      return;
    }
    if (TEL_OBLIGATOIRE && !tel) {
      note.textContent = 'Merci d\u2019indiquer votre téléphone.';
      return;
    }

    state.activite = act;
    state.ville = ville;
    state.nom = nom;
    state.email = email;
    state.tel = tel;
    state.currentAxis = 0;

    // Lead capturé dès le départ — même si le test est abandonné ensuite
    sendLead('Test démarré');

    renderAxis();
    show(stepQuiz);
  });

  btnNext.addEventListener('click', function () {
    if (!saveCurrentAxis()) {
      document.getElementById('quiz-hint').textContent = 'Répondez aux 3 questions pour continuer.';
      return;
    }
    if (state.currentAxis < 5) {
      state.currentAxis++;
      swapAxis(1);
      scrollToQuizIfNeeded();
    } else {
      quizBar.style.width = '100%';
      renderResult();
    }
  });

  btnPrev.addEventListener('click', function () {
    saveCurrentAxis();
    if (state.currentAxis > 0) {
      state.currentAxis--;
      swapAxis(-1);
      scrollToQuizIfNeeded();
    }
  });

  btnRestart.addEventListener('click', function () {
    state.answers = AXES.map(function (a) { return a.questions.map(function () { return null; }); });
    state.currentAxis = 0;
    document.getElementById('score-form-status').textContent = '';
    show(stepIntro);
  });

  // ----- Réservation de l'audit : un seul clic -----
  btnBook.addEventListener('click', function () {
    var status = document.getElementById('score-form-status');
    var score = totalScore();

    if (emailjsReady()) {
      btnBook.disabled = true;
      btnBook.textContent = 'Envoi en cours...';
      sendLead('Demande d\u2019audit', { score: score + '/100', detail: scoreDetail() })
        .then(function (ok) {
          if (ok) {
            status.textContent = 'C\u2019est noté, ' + state.nom + ' — je vous recontacte rapidement pour fixer le créneau.';
            status.className = 'form-status ok';
            btnBook.textContent = 'Demande envoyée';
          } else {
            status.textContent = 'Erreur d\u2019envoi. Réessayez ou écrivez-moi : contact@tomsepval.fr';
            status.className = 'form-status err';
            btnBook.disabled = false;
            btnBook.textContent = 'Réserver mon rendez-vous';
          }
        });
      return;
    }

    // Fallback sans EmailJS : email pré-rempli, aucun lead perdu
    var body = 'Demande d\u2019audit via le Score de visibilité locale%0D%0A%0D%0A' +
      'Nom : ' + encodeURIComponent(state.nom) + '%0D%0A' +
      'Email : ' + encodeURIComponent(state.email) + '%0D%0A' +
      'Téléphone : ' + encodeURIComponent(state.tel || '(non renseigné)') + '%0D%0A' +
      'Activité : ' + encodeURIComponent(state.activite) + '%0D%0A' +
      'Ville : ' + encodeURIComponent(state.ville) + '%0D%0A' +
      'Score : ' + encodeURIComponent(score + '/100') + '%0D%0A' +
      'Détail : ' + encodeURIComponent(scoreDetail());
    window.location.href = 'mailto:contact@tomsepval.fr?subject=' +
      encodeURIComponent('Demande d\u2019audit — ' + state.nom + ' (' + score + '/100)') +
      '&body=' + body;
    status.textContent = 'Votre messagerie s\u2019ouvre avec la demande pré-remplie — il ne reste qu\u2019à envoyer.';
    status.className = 'form-status ok';
  });
})();
