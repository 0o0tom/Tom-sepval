// =========================================================
// LANDING CRÉATION SITE WEB (achat) — pré-remplissage formule + formulaire
// =========================================================
(function () {
  'use strict';

  // Quand on clique un bouton "Demander cette formule", on pré-sélectionne
  // la formule dans le formulaire pour ne pas la redemander.
  var packSelect = document.getElementById('cf-pack');
  document.querySelectorAll('[data-pack]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var pack = btn.getAttribute('data-pack');
      if (packSelect && pack) {
        for (var i = 0; i < packSelect.options.length; i++) {
          if (packSelect.options[i].value === pack) { packSelect.selectedIndex = i; break; }
        }
      }
    });
  });

  // ---- Formulaire ----
  var EMAILJS_SERVICE_ID = 'service_w5n7idr';
  var EMAILJS_TEMPLATE_ID = 'template_aknwx43';

  var form = document.getElementById('creation-form');
  if (!form) return;

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var status = document.getElementById('creation-form-status');
    var submitBtn = form.querySelector('button[type="submit"]');

    var data = {
      nom: form.nom.value.trim(),
      telephone: form.telephone.value.trim(),
      email: form.email.value.trim(),
      activite: form.activite.value.trim(),
      pack: form.pack.value,
      ville: form.ville.value.trim(),
      message: form.message.value.trim() || '(non renseigné)',
      source: 'Landing création site web'
    };

    var emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email);
    if (!data.nom || !data.telephone || !data.email || !data.activite || !data.pack || !data.ville) {
      status.textContent = 'Merci de remplir tous les champs obligatoires.';
      status.className = 'form-status err';
      return;
    }
    if (!emailOk) {
      status.textContent = 'Cet email ne semble pas valide.';
      status.className = 'form-status err';
      return;
    }

    var ready = typeof emailjs !== 'undefined' && EMAILJS_SERVICE_ID !== 'REMPLACE_MOI';

    if (!ready) {
      var body = 'Demande de création de site via la landing Achat%0D%0A%0D%0A' +
        'Nom : ' + encodeURIComponent(data.nom) + '%0D%0A' +
        'Téléphone : ' + encodeURIComponent(data.telephone) + '%0D%0A' +
        'Email : ' + encodeURIComponent(data.email) + '%0D%0A' +
        'Activité : ' + encodeURIComponent(data.activite) + '%0D%0A' +
        'Formule : ' + encodeURIComponent(data.pack) + '%0D%0A' +
        'Ville : ' + encodeURIComponent(data.ville) + '%0D%0A' +
        'Projet : ' + encodeURIComponent(data.message);
      window.location.href = 'mailto:contact@tomsepval.fr?subject=' +
        encodeURIComponent('Demande site — ' + data.nom + ' (' + data.pack + ')') +
        '&body=' + body;
      status.textContent = 'Votre messagerie s\u2019ouvre avec la demande pré-remplie — il ne reste qu\u2019à envoyer.';
      status.className = 'form-status ok';
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Envoi en cours...';
    emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, data)
      .then(function () {
        status.textContent = 'C\u2019est envoyé — je vous recontacte rapidement pour affiner votre projet.';
        status.className = 'form-status ok';
        form.reset();
      })
      .catch(function () {
        status.textContent = 'Erreur d\u2019envoi. Réessayez ou écrivez-moi : contact@tomsepval.fr';
        status.className = 'form-status err';
      })
      .finally(function () {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Demander mon site';
      });
  });
})();
