// =========================================================
// Menu mobile
// =========================================================
document.addEventListener('DOMContentLoaded', function () {
  var toggle = document.querySelector('.nav-toggle');
  var links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.setAttribute('aria-expanded', 'false');
    toggle.addEventListener('click', function () {
      var open = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      toggle.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
    });
    links.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        links.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-label', 'Ouvrir le menu');
      });
    });
  }

  // =========================================================
  // FAQ accordion
  // =========================================================
  document.querySelectorAll('.faq-item').forEach(function (item) {
    var q = item.querySelector('.faq-q');
    if (!q) return;
    q.addEventListener('click', function () {
      var wasOpen = item.classList.contains('open');
      item.parentElement.querySelectorAll('.faq-item').forEach(function (i) {
        i.classList.remove('open');
        var iq = i.querySelector('.faq-q');
        if (iq) iq.setAttribute('aria-expanded', 'false');
      });
      if (!wasOpen) {
        item.classList.add('open');
        q.setAttribute('aria-expanded', 'true');
      }
    });
  });

  // =========================================================
  // Formulaire audit gratuit — EmailJS
  //
  // Étapes pour activer l'envoi réel (compte EmailJS gratuit) :
  // 1. Crée un compte sur https://www.emailjs.com
  // 2. Récupère ta Public Key, ton Service ID et ton Template ID
  // 3. Remplace les 3 valeurs ci-dessous
  // 4. Décommente la ligne emailjs.init(...) et le script EmailJS
  //    dans le <head> de chaque page HTML (déjà en place, juste
  //    commenté pour ne pas déclencher d'erreur avant configuration)
  // =========================================================
  var EMAILJS_PUBLIC_KEY = '-Pwnhq7pG-yjAGp2H';
  var EMAILJS_SERVICE_ID = 'service_w5n7idr';
  var EMAILJS_TEMPLATE_ID = 'template_aknwx43';

  var form = document.getElementById('audit-form');
  if (!form) return;

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var status = document.getElementById('form-status');
    var submitBtn = form.querySelector('button[type="submit"]');

    var data = {
      nom: form.nom.value.trim(),
      activite: form.activite.value,
      ville: form.ville.value.trim(),
      contact: form.contact.value.trim()
    };

    if (!data.nom || !data.activite || !data.ville || !data.contact) {
      status.textContent = 'Merci de remplir tous les champs.';
      status.className = 'form-status err';
      return;
    }

    // Si EmailJS n'est pas configuré, on simule la confirmation
    // pour ne jamais bloquer le visiteur, et on log les données
    // en console pour que Tom puisse les récupérer manuellement
    // en attendant la config EmailJS.
    if (typeof emailjs === 'undefined' || EMAILJS_PUBLIC_KEY === 'REMPLACE_MOI') {
      console.log('Nouvelle demande d’audit (EmailJS non configuré) :', data);
      status.textContent = 'Demande enregistrée localement — configure EmailJS pour la recevoir par email (voir commentaires dans main.js).';
      status.className = 'form-status ok';
      form.reset();
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Envoi en cours...';

    emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, data)
      .then(function () {
        status.textContent = 'Demande envoyée — je vous recontacte rapidement.';
        status.className = 'form-status ok';
        form.reset();
      })
      .catch(function () {
        status.textContent = 'Erreur d’envoi. Réessayez ou contactez-moi directement.';
        status.className = 'form-status err';
      })
      .finally(function () {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Réserver mon audit gratuit';
      });
  });
});

// =========================================================
// RÉVÉLATION AU SCROLL — auto-appliquée aux modules
// texte + photo. Ajouter la classe .reveal (ou .reveal-img
// pour une image) à n'importe quel nouvel élément suffit.
// =========================================================
(function () {
  'use strict';
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  if (!('IntersectionObserver' in window)) return;

  // Modules ciblés automatiquement sur tout le site
  var IMAGES = '.case-detail .img-col, .approach-duo img, .hero-visual img, .portfolio-note img, .case-gallery img, .brochure-pages img';
  var TEXTS  = '.case-detail .text-col, .case-editorial-head, .portfolio-brochure-head, .approach-words, .approach-text, .case-card, .step, .form-pitch, .audit-start';

  document.querySelectorAll(IMAGES).forEach(function (el) { el.classList.add('reveal-img'); });
  document.querySelectorAll(TEXTS).forEach(function (el) { el.classList.add('reveal'); });
  // Le texte d'un cas client suit sa photo d'un souffle
  document.querySelectorAll('.case-detail .text-col').forEach(function (el) { el.classList.add('reveal-delay'); });

  // Décalage court et borné : au-delà de 3 éléments le retard devient une
  // attente, pas un rythme. 3 × 60 ms = 180 ms maximum, contre 500 ms avant.
  function stagger(selector) {
    document.querySelectorAll(selector).forEach(function (el, i) {
      el.style.transitionDelay = (Math.min(i, 3) * 0.06) + 's';
    });
  }
  stagger('.case-gallery img, .brochure-pages img');
  stagger('.steps .step');

  // Une fois l'apparition jouée, l'élément redevient un élément normal :
  // on retire le délai, le hint compositeur et les classes de révélation,
  // pour qu'il retrouve ses propres transitions de survol.
  function settle(el) {
    el.style.transitionDelay = '';
    el.classList.remove('will-animate', 'reveal', 'reveal-img', 'reveal-delay', 'is-visible');
  }

  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) return;
      var el = entry.target;
      observer.unobserve(el);

      // will-change juste avant le mouvement, pas à la charge de la page
      el.classList.add('will-animate');
      requestAnimationFrame(function () {
        el.classList.add('is-visible');
      });

      var done = false;
      function finish() {
        if (done) return;
        done = true;
        el.removeEventListener('transitionend', onEnd);
        settle(el);
      }
      function onEnd(e) {
        if (e.target === el && e.propertyName === 'opacity') finish();
      }
      el.addEventListener('transitionend', onEnd);
      // Filet de sécurité : si la transition ne se déclenche pas (élément
      // masqué, onglet en arrière-plan), on nettoie quand même.
      setTimeout(finish, 1200);
    });
    // Amorcer avant l'entrée à l'écran : l'élément est déjà posé quand le
    // regard arrive dessus, au lieu d'apparaître en retard sur le scroll.
  }, { threshold: 0, rootMargin: '0px 0px -10% 0px' });

  document.querySelectorAll('.reveal, .reveal-img').forEach(function (el) {
    observer.observe(el);
  });
})();

